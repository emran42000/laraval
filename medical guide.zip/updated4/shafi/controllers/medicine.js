// DECLARATION
var express = require('express');
var router = express.Router();
var asyncValidator = require('async-validator');
var userRules = require.main.require('./validation-rules/user');

var userModel = require.main.require('./models/user-model');

router.get('/', function(req, res){
	userModel.getAll(function(result){
		res.render('home/medicine', {userList: result, name: req.session.loggedUser.username});
		//res.json(result);
	});
});

router.get('/medicine', function(req, res){
	res.render('home/medicine', {errs: []});
});


module.exports = router;
