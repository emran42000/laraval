-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 17, 2018 at 06:14 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `node`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminname` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminname`, `password`) VALUES
('admin1', 'admin1'),
('admin2', 'admin2');

-- --------------------------------------------------------

--
-- Table structure for table `ambulence`
--

CREATE TABLE `ambulence` (
  `Aid` int(30) NOT NULL,
  `Aname` varchar(30) NOT NULL,
  `Alocation` varchar(30) NOT NULL,
  `Aphone` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ambulence`
--

INSERT INTO `ambulence` (`Aid`, `Aname`, `Alocation`, `Aphone`) VALUES
(1, 'Lab Aid Hospital', 'Uttara', '01535425262'),
(2, 'AL Madina Hospital', 'Khilkhet', '01712526232'),
(3, 'Square Hospital', 'Dhanmondi', '01652324252'),
(4, 'American Idea Hospital', 'Gulshan', '01712526285');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`) VALUES
(1, 'Fever', 'N/A');

-- --------------------------------------------------------

--
-- Table structure for table `medicines`
--

CREATE TABLE `medicines` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `price` double NOT NULL,
  `quantity` int(11) NOT NULL,
  `catId` int(11) NOT NULL,
  `totalItem` int(100) NOT NULL,
  `sold` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medicines`
--

INSERT INTO `medicines` (`id`, `name`, `price`, `quantity`, `catId`, `totalItem`, `sold`) VALUES
(1, 'napa', 10, 1, 1, 260, 40),
(2, 'parasitamle', 15, 1, 1, 290, 0),
(3, 'rolac', 20, 1, 2, 190, 110),
(4, 'painak', 22, 1, 2, 300, 0),
(5, 'lonapam', 100, 1, 3, 295, 5);

-- --------------------------------------------------------

--
-- Table structure for table `medorder`
--

CREATE TABLE `medorder` (
  `orusername` int(30) NOT NULL,
  `ormedicine` int(30) NOT NULL,
  `orquantity` int(30) NOT NULL,
  `orprice` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pharmacy`
--

CREATE TABLE `pharmacy` (
  `Pid` int(30) NOT NULL,
  `Pname` varchar(30) NOT NULL,
  `Plocation` varchar(30) NOT NULL,
  `Pphone` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pharmacy`
--

INSERT INTO `pharmacy` (`Pid`, `Pname`, `Plocation`, `Pphone`) VALUES
(1, 'Lazz Pharma', 'Uttara', '01521425232'),
(2, 'Ajij Pharmacy', 'Kolabagan', '01721425232'),
(3, 'shines pharma', 'bongobazar', '01652324252'),
(4, 'Medical care Pharmacy', 'Banani', '01852423212'),
(5, 'Foyejunnesa Pharma', 'Shahbag', '01652324212');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userId` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `phone` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userId`, `username`, `password`, `address`, `phone`) VALUES
(1, 'kashem', 'kashemjkhj', 'Purbachal', 1524587565),
(6, 'Jobbar', 'hhhhhhhf', 'gulshan', 1854256523),
(7, 'Samad', 'samadfg', 'adabor', 1985654525),
(8, 'xyz', 'fffffffff', 'Khilkhet', 1652425875),
(9, 'shafi', 'shafi1', 'Uttara', 1521422562),
(10, 'abul', 'sdfjhsdfj', 'Kakoli', 1652427895),
(41, 'shafii', 'hsdfkhgj', 'fsdjfhsdfh', 1452124252),
(44, 'shuvo', 'sfhjvn54', 'uttara', 0),
(45, 'maisha', 'bheukksj', 'Mohammadpur', 1575856526),
(46, 'Fatin', 'sdfjuekj', 'Tongi', 1758452152),
(47, 'tamanna', 'tamanna12', 'mirpur', 1521258226);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `medicines`
--
ALTER TABLE `medicines`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catId` (`catId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userId`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `medicines`
--
ALTER TABLE `medicines`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
